# 1.2.0

- Updated `televerse` version to 2.4.0

# 1.1.0

- Updated the transformer definition

# 0.0.0

- Initial version.
